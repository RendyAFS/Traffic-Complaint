<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <?php echo $__env->make('components.admin.modal-upload-file-aduan', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="mb-4">
            <div class="mb-3" data-aos="fade-up">
                <span class="fs-3 fw-bold">Input Data Aduan</span>
            </div>
            <?php echo $__env->make('components.admin.input-complaint', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="mb-4">
            <div class="mb-3" data-aos="fade-right">
                <span class="fs-3 fw-bold">Tabel Riwayat Aduan</span>
            </div>
            <?php echo $__env->make('components.admin.table-history-complaint', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script type="module">
        // alert upload
        <?php if(session('success-upload')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil Upload',
                text: '<?php echo e(session('success-upload')); ?>',
                confirmButtonText: 'OK',
                confirmButtonColor: '#0D2454'
            });
        <?php endif; ?>
        <?php if(session('success-update')): ?>
            Swal.fire({
                icon: 'success',
                title: 'Berhasil Upload',
                text: '<?php echo e(session('success-upload')); ?>',
                confirmButtonText: 'OK',
                confirmButtonColor: '#0D2454'
            });
        <?php endif; ?>
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\Traffic-Complaint\resources\views/page-admin/index.blade.php ENDPATH**/ ?>