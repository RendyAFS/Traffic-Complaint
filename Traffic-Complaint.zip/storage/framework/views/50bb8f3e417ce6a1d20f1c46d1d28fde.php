<div class="mb-3">
    <label for="exampleFormControlTextarea1" class="form-label fw-bold">Masukkan Aduan</label>
    <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
</div>
<?php /**PATH D:\Job\Project\Traffic-Complaint\resources\views/components/user/card-textinput.blade.php ENDPATH**/ ?>