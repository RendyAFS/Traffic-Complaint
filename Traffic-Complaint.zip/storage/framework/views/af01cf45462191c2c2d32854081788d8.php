<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <div class="container py-2">
        <a class="navbar-brand font-white fw-bold" href="<?php echo e(url('/')); ?>">
            Traffic Complaint
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav me-auto">
                <?php if(auth()->guard()->check()): ?>
                    <?php if(Auth::user()->level == 'Admin'): ?>
                        <!-- Tampilkan menu hanya jika tidak berada di halaman root '/' -->
                        <?php if(!Request::is('/')): ?>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(Route::is('admin.index') ? 'fw-bold font-primary nav-active' : ''); ?>" aria-current="page"
                                    href="<?php echo e(route('admin.index')); ?>">Aduan</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link <?php echo e(Route::is('admin.done.complaint') ? 'fw-bold font-primary nav-active' : ''); ?>" aria-current="page"
                                    href="<?php echo e(route('admin.done.complaint')); ?>">Aduan Selesai</a>
                            </li>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ms-auto">
                <?php if(auth()->guard()->guest()): ?>
                    <?php if(Route::has('login')): ?>
                        <li class="nav-item">
                            <a class="nav-link btn-login px-4 me-2 mb-3 mb-md-0 mt-5 mt-md-0" href="<?php echo e(route('login')); ?>">Login</a>
                        </li>
                    <?php endif; ?>

                    <?php if(Route::has('register')): ?>
                        <li class="nav-item">
                            <a class="nav-link btn-registrasi px-4" href="<?php echo e(route('register')); ?>">Registrasi</a>
                        </li>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if(Request::is('/')): ?>
                        <!-- Tampilkan link ke /home jika sudah login dan berada di halaman landing page (/) -->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/home')); ?>">Masuk</a>
                        </li>
                    <?php else: ?>
                        <!-- Dropdown menu jika berada di halaman lain -->
                        <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button"
                                data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="navbarDropdown">
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH D:\Job\Project\Traffic-Complaint\resources\views/components/navbar.blade.php ENDPATH**/ ?>