<script>
    <?php if(session('status') === 'error'): ?>
        Swal.fire({
            icon: 'warning',
            title: 'Akses Ditolak',
            text: '<?php echo e(session('message')); ?>',
            confirmButtonText: 'OK',
            confirmButtonColor: '#0D2454'
        });
    <?php endif; ?>
</script>
<?php /**PATH C:\laragon\www\Traffic-Complaint\resources\views/components/sessionAccess.blade.php ENDPATH**/ ?>