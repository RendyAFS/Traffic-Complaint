<div class="content mb-5">
    <div class="text-center mb-5" data-aos="fade-up">
        <span class="fw-bold fs-3 font-blue mb-4">Aduan Terbaru</span>
    </div>
    <div class="row">
        <?php $__currentLoopData = $latestComplaints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $complient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-4 mb-4">
                <div class="card h-100 rounded-4 border-0 shadow" data-aos="flip-left">
                    <?php if($complient->gambar): ?>
                        <!-- Menampilkan gambar jika tersedia -->
                        <img src="<?php echo e(asset('storage/file-gambar/' . $complient->gambar)); ?>" alt="<?php echo e($complient->gambar); ?>"
                            class="card-img-top img-fluid rounded-top-4" style="object-fit: cover; height: 250px;">
                    <?php else: ?>
                        <!-- Placeholder jika gambar null -->
                        <div class="d-flex justify-content-center align-items-center rounded-4"
                            style="height: 250px; background-color: #f8f9fa;">
                            <i class="bi bi-image fs-1"></i>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <span class="fw-bold"><?php echo e(Str::words($complient->text_complaint, 5)); ?></span>
                        <div class="d-flex justify-content-end">
                            <a href="#" class="font-blue fw-bold" data-bs-toggle="modal" data-bs-target="#complaintModal<?php echo e($complient->id); ?>">Read More</a><br>
                        </div>
                        <span class="fs-6 fst-italic"><?php echo e($complient->created_at->translatedFormat('d-F-Y')); ?></span>
                    </div>
                </div>
            </div>

            <!-- Modal -->
            <div class="modal fade" id="complaintModal<?php echo e($complient->id); ?>" tabindex="-1" aria-labelledby="complaintModalLabel<?php echo e($complient->id); ?>" aria-hidden="true">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title fw-bold" id="complaintModalLabel<?php echo e($complient->id); ?>">Detail Aduan</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <?php if($complient->gambar): ?>
                                <img src="<?php echo e(asset('storage/file-gambar/' . $complient->gambar)); ?>" alt="<?php echo e($complient->gambar); ?>"
                                    class="img-fluid mb-3" style="object-fit: cover; width: 100%; max-height: 400px;">
                            <?php else: ?>
                                <div class="d-flex justify-content-center align-items-center mb-3"
                                    style="height: 250px; background-color: #f8f9fa;">
                                    <i class="bi bi-image fs-1"></i>
                                </div>
                            <?php endif; ?>
                            <p><?php echo e($complient->text_complaint); ?></p>
                            <p class="fs-6 fst-italic">Tanggal Aduan: <?php echo e($complient->created_at->translatedFormat('d-F-Y')); ?></p>
                            <p class="fs-6 fst-italic">Loaksi: <?php echo e($complient->lokasi); ?></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btnc-red" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\laragon\www\Traffic-Complaint\resources\views/components/guest/content-3.blade.php ENDPATH**/ ?>