<?php
if (class_exists('ZipArchive')) {
    echo 'ZipArchive is available';
} else {
    echo 'ZipArchive is not available';
}
